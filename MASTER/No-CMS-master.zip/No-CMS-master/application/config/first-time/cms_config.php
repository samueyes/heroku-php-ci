<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['__cms_version']        = '0.0.0';
$config['__cms_chipper']        = '';
$config['__cms_table_prefix']   = '';
