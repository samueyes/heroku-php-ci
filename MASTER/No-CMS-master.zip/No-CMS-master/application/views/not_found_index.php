<?php if (!defined('BASEPATH')) exit('No direct script access allowed');?>

<h1>404 Page not found</h1>
<p>
	Sorry, the page does not exists. 
	Please go <a href="{{ site_url }}" class="btn btn-primary">back</a> 
	and see if you can find what you are looking for.
</p>