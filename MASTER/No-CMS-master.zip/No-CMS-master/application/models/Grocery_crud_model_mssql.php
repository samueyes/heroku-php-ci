<?php
class Grocery_crud_model_mssql extends Grocery_crud_generic_model{

}
