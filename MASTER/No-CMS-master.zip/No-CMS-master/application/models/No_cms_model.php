<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class No_cms_model extends CMS_Model{}