<?php
class Grocery_crud_model_mysql extends Grocery_crud_generic_model{

}
