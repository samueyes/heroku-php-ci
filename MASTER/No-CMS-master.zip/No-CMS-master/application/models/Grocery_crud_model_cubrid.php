<?php
class Grocery_crud_model_cubrid extends Grocery_crud_generic_model{

}
