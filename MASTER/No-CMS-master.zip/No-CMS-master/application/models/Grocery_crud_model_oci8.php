<?php
class Grocery_crud_model_oci8 extends Grocery_crud_generic_model{

}
