<?php
class Grocery_crud_model_sqlsrv extends Grocery_crud_generic_model{

}
