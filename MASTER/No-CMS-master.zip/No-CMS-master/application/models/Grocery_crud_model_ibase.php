<?php
class Grocery_crud_model_ibase extends Grocery_crud_generic_model{

}
